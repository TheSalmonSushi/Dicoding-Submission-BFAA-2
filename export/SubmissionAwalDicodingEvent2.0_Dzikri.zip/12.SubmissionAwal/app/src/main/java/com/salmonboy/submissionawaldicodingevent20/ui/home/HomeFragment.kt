package com.salmonboy.submissionawaldicodingevent20.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.salmonboy.submissionawaldicodingevent20.data.response.ListEventsItem
import com.salmonboy.submissionawaldicodingevent20.databinding.FragmentHomeBinding
import com.salmonboy.submissionawaldicodingevent20.ui.detail.EventDetailActivity
import com.salmonboy.submissionawaldicodingevent20.ui.home.homeAdapter.HomeHorizontalAdapter
import com.salmonboy.submissionawaldicodingevent20.ui.home.homeAdapter.HomeVerticalAdapter

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private val homeViewModel: HomeViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Setup RecyclerView
        binding.recyclerViewGridHorizontal.layoutManager = GridLayoutManager(
            requireContext(), 1, GridLayoutManager.HORIZONTAL, false
        )
        binding.recyclerViewLinearVertical.layoutManager = GridLayoutManager(
            requireContext(), 2, LinearLayoutManager.HORIZONTAL, false
        )

        // Setup ViewModel Observers
        homeViewModel.upcomingEvents.observe(viewLifecycleOwner) { events ->
            setUpcomingEventsData(events)
        }
        homeViewModel.isUpcomingLoading.observe(viewLifecycleOwner) {
            binding.progressBarGrid.visibility = if (it) View.VISIBLE else View.GONE
        }
        homeViewModel.finishedEvents.observe(viewLifecycleOwner) { events ->
            setFinishedEventsData(events)
        }
        homeViewModel.isFinishedLoading.observe(viewLifecycleOwner) {
            binding.progressBarList.visibility = if (it) View.VISIBLE else View.GONE
        }
        homeViewModel.errorMessage.observe(viewLifecycleOwner) { errorMessage ->
            Toast.makeText(requireContext(), errorMessage, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun setUpcomingEventsData(events: List<ListEventsItem>) {
        val adapter = HomeHorizontalAdapter { event ->
            val intent = Intent(requireContext(), EventDetailActivity::class.java)
            intent.putExtra("EVENT_ID", event.id.toString())
            startActivity(intent)
        }
        adapter.submitList(events)
        binding.recyclerViewGridHorizontal.adapter = adapter
    }

    private fun setFinishedEventsData(events: List<ListEventsItem>) {
        val adapter = HomeVerticalAdapter { event ->
            val intent = Intent(requireContext(), EventDetailActivity::class.java)
            intent.putExtra("EVENT_ID", event.id.toString())
            startActivity(intent)
        }
        adapter.submitList(events)
        binding.recyclerViewLinearVertical.adapter = adapter
    }
}