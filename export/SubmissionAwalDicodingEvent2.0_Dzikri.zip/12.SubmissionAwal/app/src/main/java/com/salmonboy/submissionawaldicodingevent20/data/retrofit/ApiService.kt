package com.salmonboy.submissionawaldicodingevent20.data.retrofit

import com.salmonboy.submissionawaldicodingevent20.data.response.DicodingEventResponse
import com.salmonboy.submissionawaldicodingevent20.data.response.EventDetailResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query


interface ApiService {

    @GET("events")
    fun getDicodingEvents(
        @Query("active") active: Int = 1,
        @Query("q") query: String? = null,
        @Query("limit") page: Int = 100
    ): Call<DicodingEventResponse>

    @GET("events/{id}")
    fun getEventDetail(
        @Path("id") id: String
    ): Call<EventDetailResponse>
}