package com.salmonboy.submissionawaldicodingevent20.ui.detail

import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide
import com.salmonboy.submissionawaldicodingevent20.databinding.ActivityEventDetailBinding
import java.util.Locale

class EventDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEventDetailBinding
    private val eventDetailViewModel: EventDetailViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityEventDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupObservers()

        val eventId = intent.getStringExtra("EVENT_ID") ?: return

        eventDetailViewModel.fetchEventDetail(eventId)

        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun setupObservers() {
        eventDetailViewModel.eventDetail.observe(this) { eventDetail ->
            // Title and Organizer
            binding.tvEventTitle.text = eventDetail.name

            val formattedOrganiser = "Diselenggarakan Oleh \n${eventDetail.ownerName}"
            binding.tvEventOrganiser.text = formattedOrganiser

            // Description
            binding.tvEventDesc.text = HtmlCompat.fromHtml(
                eventDetail.description,
                HtmlCompat.FROM_HTML_MODE_LEGACY
            )

            // Date, Quota, Registrants, and Image
            val rawDate = eventDetail.beginTime
            val formattedDate = formatDate(rawDate)
            binding.tvEventDate.text = formattedDate

            val formattedQuotaLeft = "Sisa Kuota: ${eventDetail.quota - eventDetail.registrants}"
            binding.tvEventQuota.text = formattedQuotaLeft

            Glide.with(this).load(eventDetail.imageLogo).into(binding.ivItemPhoto)

            binding.linkEventButton.setOnClickListener {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(eventDetail.link))
                startActivity(intent)
            }
        }

        eventDetailViewModel.isLoading.observe(this) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        eventDetailViewModel.errorMessage.observe(this) { errorMessage ->
            Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
        }

    }

    private fun formatDate(apiDate: String): String {
        val apiDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val desiredDateFormat = SimpleDateFormat("dd MMMM yyyy\n HH:mm", Locale.getDefault())

        return try {
            val date = apiDateFormat.parse(apiDate)
            desiredDateFormat.format(date)
        } catch (e: Exception) {
            apiDate
        }
    }
}