package com.salmonboy.submissionawaldicodingevent20.ui.upcoming

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import com.salmonboy.submissionawaldicodingevent20.data.response.ListEventsItem
import com.salmonboy.submissionawaldicodingevent20.databinding.FragmentUpcomingBinding
import com.salmonboy.submissionawaldicodingevent20.ui.adapter.event.EventAdapter
import com.salmonboy.submissionawaldicodingevent20.ui.detail.EventDetailActivity

class UpcomingFragment : Fragment() {

    private var _binding: FragmentUpcomingBinding? = null
    private val binding get() = _binding!!

    private val upcomingViewModel: UpcomingViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentUpcomingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()

        with(binding) {
            searchView.setupWithSearchBar(searchBar)
            searchView
                .editText
                .setOnEditorActionListener { _, _, _ ->
                    val query = searchView.text.toString()
                    upcomingViewModel.filterEvents(query)
                    searchView.hide()
                    searchBar.setText(query)
                    false
                }
        }

        upcomingViewModel.filteredEvents.observe(viewLifecycleOwner) { events ->
            setEventsData(events)
        }
        upcomingViewModel.listEvent.observe(viewLifecycleOwner) { events ->
            setEventsData(events)
        }
        upcomingViewModel.isLoading.observe(viewLifecycleOwner) {
            showLoading(it)
        }
        upcomingViewModel.errorMessage.observe(viewLifecycleOwner) { errorMessage ->
            Toast.makeText(requireContext(), errorMessage, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun setupRecyclerView() {
        val orientation = resources.configuration.orientation
        val layoutManager = if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            GridLayoutManager(requireContext(), 1, GridLayoutManager.HORIZONTAL, false)
        } else {
            GridLayoutManager(requireContext(), 2, GridLayoutManager.VERTICAL, false)
        }
        binding.rvUpcomingEvent.layoutManager = layoutManager
    }

    private fun setEventsData(events: List<ListEventsItem>) {
        val adapter = EventAdapter { event ->
            val intent = Intent(requireContext(), EventDetailActivity::class.java)
            intent.putExtra("EVENT_ID", event.id.toString())
            startActivity(intent)
        }
        adapter.submitList(events)
        binding.rvUpcomingEvent.adapter = adapter
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}